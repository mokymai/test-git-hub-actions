# ============================================================================
# Zotero
#
# citr
# https://github.com/ropensci/rcrossref   remotes::install_github("ropensci/rcrossref")
# https://github.com/retorquere/zotero-better-bibtex [Connect R "citr" to Zotero]
# ============================================================================
# https://r-lib.github.io/ymlthis/articles/yaml-overview.html
# ============================================================================
# https://github.com/benmarwick/wordcountaddin
# https://github.com/tjmahr/WrapRmd

# https://github.com/gadenbuie/regexplain

# https://github.com/gadenbuie/ermoji     remotes::install_github("gadenbuie/ermoji")
#
# https://github.com/yonicd/rsam          remotes::install_github('yonicd/rsam')
# https://github.com/mvkorpel/uniscape
# https://github.com/vnijs/gitgadget
# https://github.com/Timag/imageclipr
# https://github.com/lbusett/insert_table
# https://github.com/dkilfoyle/rpivotGadget