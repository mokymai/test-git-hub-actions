go_to_line <- function() {
  rstudioapi::executeCommand("goToLine", quiet = TRUE)
}
# rstudioapi::executeCommand("importDatasetFromCsvUsingBase")
# rstudioapi::executeCommand("importDatasetFromCsvUsingReadr")
# rstudioapi::executeCommand("importDatasetFromSAS")
# rstudioapi::executeCommand("importDatasetFromSAV")
# rstudioapi::executeCommand("importDatasetFromStata")
# rstudioapi::executeCommand("importDatasetFromXLS")
# rstudioapi::executeCommand("modifyKeyboardShortcuts")
